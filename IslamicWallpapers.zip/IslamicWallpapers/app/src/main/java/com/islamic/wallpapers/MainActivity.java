package com.islamic.wallpapers;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Bundle;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        // يغلق نافذة المعاينة النهائية إن كانت مفتوحة، وإلا يخرج من التطبيق
        web.evaluateJavascript(
            "(function(){var o=document.getElementById('ov');if(o&&!o.hidden){o.hidden=true;return 1}return 0})()",
            v -> { if (!"1".equals(v)) MainActivity.super.onBackPressed(); });
    }

    @Override protected void onPause() { super.onPause(); web.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }
    @Override protected void onDestroy() { web.destroy(); super.onDestroy(); }

    private void toast(final String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
    }

    /** الجسر بين صفحة الويب والنظام. يُستدعى من JavaScript عبر window.Android */
    public class Bridge {

        /** mode: "home" | "lock" | "both" */
        @JavascriptInterface
        public void setWallpaper(final String base64Png, final String mode) {
            new Thread(() -> {
                try {
                    byte[] raw = Base64.decode(base64Png, Base64.DEFAULT);
                    Bitmap src = BitmapFactory.decodeByteArray(raw, 0, raw.length);
                    if (src == null) { toast("تعذر قراءة الصورة"); return; }

                    DisplayMetrics dm = getResources().getDisplayMetrics();
                    int W = dm.widthPixels, H = dm.heightPixels;
                    Bitmap out = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
                    Canvas c = new Canvas(out);
                    c.drawColor(Color.BLACK);
                    float k = Math.max(W / (float) src.getWidth(), H / (float) src.getHeight());
                    float dw = src.getWidth() * k, dh = src.getHeight() * k;
                    c.save();
                    c.translate((W - dw) / 2f, (H - dh) / 2f);
                    c.scale(k, k);
                    c.drawBitmap(src, 0, 0, new Paint(Paint.FILTER_BITMAP_FLAG));
                    c.restore();
                    src.recycle();

                    int flags;
                    if ("home".equals(mode)) flags = WallpaperManager.FLAG_SYSTEM;
                    else if ("lock".equals(mode)) flags = WallpaperManager.FLAG_LOCK;
                    else flags = WallpaperManager.FLAG_SYSTEM | WallpaperManager.FLAG_LOCK;

                    WallpaperManager.getInstance(MainActivity.this).setBitmap(out, null, true, flags);
                    toast("home".equals(mode) ? "تم التعيين للشاشة الرئيسية"
                        : "lock".equals(mode) ? "تم التعيين لشاشة القفل"
                        : "تم التعيين للشاشة الرئيسية والقفل");
                } catch (Throwable e) {
                    toast("تعذر تعيين الخلفية: " + e.getMessage());
                }
            }).start();
        }

        /** يفتح شاشة معاينة الخلفية الحية (الساعة تتحدث تلقائيا) */
        @JavascriptInterface
        public void openLive() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
                    i.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                        new ComponentName(MainActivity.this, ClockWallpaperService.class));
                    startActivity(i);
                } catch (Throwable e) {
                    try {
                        startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER));
                    } catch (Throwable e2) {
                        toast("جهازك لا يدعم الخلفيات الحية");
                    }
                }
            });
        }
    }
}
