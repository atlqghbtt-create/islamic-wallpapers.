package com.islamic.wallpapers;

import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * خلفية حية: تعرض نفس صفحة التطبيق (الخلفية + الساعة + التاريخ بإعداداتك المحفوظة)
 * وتعيد رسمها كل ثانية (إن فعّلت الثواني) أو عند بداية كل دقيقة بالضبط.
 */
public class ClockWallpaperService extends WallpaperService {

    @Override
    public Engine onCreateEngine() { return new ClockEngine(); }

    private class ClockEngine extends Engine {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private WebView web;
        private int w = 0, h = 0;
        private boolean visible = false, loaded = false;

        private final Runnable tick = this::frame;

        @Override
        public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);
            web = new WebView(ClockWallpaperService.this);
            web.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            web.setBackgroundColor(Color.BLACK);
            WebSettings s = web.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            web.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView v, String url) {
                    loaded = true;
                    handler.removeCallbacks(tick);
                    handler.postDelayed(tick, 500); // مهلة قصيرة لتحميل الخطوط والرسم
                }
            });
        }

        @Override
        public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            w = width; h = height;
            web.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
                        View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY));
            web.layout(0, 0, w, h);
            reload();
        }

        @Override
        public void onVisibilityChanged(boolean v) {
            visible = v;
            if (v) {
                if (w > 0) reload(); // إعادة التحميل لالتقاط أي تعديل جديد من التطبيق
            } else {
                handler.removeCallbacks(tick);
            }
        }

        private void reload() {
            loaded = false;
            web.loadUrl("file:///android_asset/index.html?live=1");
        }

        private void frame() {
            if (!visible || !loaded || web == null) return;
            // نحدّث الساعة فورا ثم نقرأ إن كانت الثواني مفعّلة
            web.evaluateJavascript(
                "(function(){try{render()}catch(e){}"
                + "try{return !!JSON.parse(localStorage.getItem('iw3')||'{}').sec}catch(e){return false}})()",
                value -> {
                    draw();
                    boolean sec = "true".equals(value);
                    long now = System.currentTimeMillis();
                    long delay = sec ? 1000 - (now % 1000) + 5 : 60000 - (now % 60000) + 20;
                    handler.removeCallbacks(tick);
                    if (visible) handler.postDelayed(tick, delay);
                });
        }

        private void draw() {
            SurfaceHolder holder = getSurfaceHolder();
            Canvas c = null;
            try {
                c = holder.lockCanvas();
                if (c != null) {
                    c.drawColor(Color.BLACK);
                    web.draw(c);
                }
            } catch (Throwable ignored) {
            } finally {
                if (c != null) {
                    try { holder.unlockCanvasAndPost(c); } catch (Throwable ignored) {}
                }
            }
        }

        @Override
        public void onDestroy() {
            handler.removeCallbacksAndMessages(null);
            if (web != null) { web.destroy(); web = null; }
            super.onDestroy();
        }
    }
}
